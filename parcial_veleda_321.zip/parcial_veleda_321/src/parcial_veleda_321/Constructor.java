
package parcial_veleda_321;

public class Constructor extends Superviviente implements Asignable, Capacitable{
    
    private final int habilidad;

    public Constructor(int habilidad, String codigo, String nombre, NivelExperiencia nivelDeExperiencia, boolean estadoDeDisponibilidad) {
        super(codigo, nombre, nivelDeExperiencia, estadoDeDisponibilidad);
              if(habilidad <= 0){
            throw new IllegalArgumentException("la habilidad debe ser positiva");
        }
        this.habilidad = habilidad;
    }
    
    public int getHabilidad(){
    return habilidad;
    }
    
    
    @Override 
    public int calcularAptitud(){
    return habilidad * 3 ; }
    
    @Override
   public void recibirTarea(String tarea){
       setEstadoDeDisponibilidad(false);
   }

    @Override
    public String toString() {
        return super.toString() + " Constructor{" + "habilidad=" + habilidad + '}';
    }
        @Override
   public void capacitarse(){
       System.out.println("el constructor se esta capacitando");
   }
    }