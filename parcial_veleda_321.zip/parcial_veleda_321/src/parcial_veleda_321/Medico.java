
package parcial_veleda_321;

public class Medico extends Superviviente implements Capacitable{
    private final int conocimientos;

    public Medico(int conocimientos, String codigo, String nombre, NivelExperiencia nivelDeExperiencia, boolean estadoDeDisponibilidad) {
        super(codigo, nombre, nivelDeExperiencia, estadoDeDisponibilidad);
        if(conocimientos <= 0) {
            throw new IllegalArgumentException("los conocimientos deben ser positivos");
        }
        this.conocimientos = conocimientos;
    }
    
    @Override
    public int calcularAptitud(){
    return conocimientos + 10 ;
    }
    
   @Override
   public void capacitarse(){
       System.out.println("el medico se esta capacitando");
   }

    @Override
    public String toString() {
        return super.toString() + " Medico{" + "conocimientos=" + conocimientos + '}';
    }
    
}
