
package parcial_veleda_321;

import java.util.Objects;


public abstract class Superviviente {
    private String codigo;
    private String nombre;
    private NivelExperiencia nivelDeExperiencia;
    private boolean estadoDeDisponibilidad;

    public Superviviente(String codigo, String nombre, NivelExperiencia nivelDeExperiencia, boolean estadoDeDisponibilidad) {
        if (codigo ==null || codigo.isBlank()){
            throw new IllegalArgumentException("el codigo no es valido");
        }
        if (nombre ==null || nombre.isBlank()){
            throw new IllegalArgumentException("el nombre no es valido");
        }
        if (nivelDeExperiencia ==null){
            throw new IllegalArgumentException("el nivel no es valido");
        }
        
        this.codigo = codigo;
        this.nombre = nombre;
        this.nivelDeExperiencia = nivelDeExperiencia;
        this.estadoDeDisponibilidad = estadoDeDisponibilidad;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public NivelExperiencia getNivelDeExperiencia() {
        return nivelDeExperiencia;
    }

    public boolean isEstadoDeDisponibilidad() {
        return estadoDeDisponibilidad;
    }

    public void setEstadoDeDisponibilidad(boolean estadoDeDisponibilidad) {
        this.estadoDeDisponibilidad = estadoDeDisponibilidad;
    }
    
    
    public abstract int calcularAptitud ();
    
    
    @Override 
    public boolean equals(Object o) {
        if(this == o) return true;
        if(!(o instanceof Superviviente)) return false;
        Superviviente otro = (Superviviente) o;
        return codigo.equals(otro.codigo) && nombre.equals(otro. nombre);
    }

    @Override 
    public int hashCode() {
        
        
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.codigo);
        hash = 29 * hash + Objects.hashCode(this.nombre);
        return hash;
    }

    @Override
    public String toString() {
        return "Superviviente{" + "codigo=" + codigo + ", nombre=" + nombre + 
                ", nivelDeExperiencia=" + nivelDeExperiencia +
                ", estadoDeDisponibilidad=" + estadoDeDisponibilidad + '}';
    }
    
    
}


