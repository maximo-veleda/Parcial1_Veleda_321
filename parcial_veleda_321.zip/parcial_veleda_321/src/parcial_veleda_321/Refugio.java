
package parcial_veleda_321;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class Refugio {
    private final String nombre;
    private final Set<Superviviente> supervivientes;

    public Refugio(String nombre) {
        if (nombre ==null || nombre.isBlank()){
            throw new IllegalArgumentException("el nombre no es valido");
        }
        this.nombre = nombre;
        this.supervivientes = new LinkedHashSet<Superviviente>();
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void agregarSuperviviente(Superviviente superviviente)throws SupervivienteDuplicadoException{
        if(superviviente == null){
            throw new IllegalArgumentException(" el superviviente no puede ser null");
        }
        if(!supervivientes.add(superviviente)){
        throw new SupervivienteDuplicadoException("ya existe un superviviente con el codigo" + 
                superviviente.getCodigo() + "y el nombre" + superviviente.getNombre());
    }
    }
    
    public List<Superviviente> obtenerSupervivente(){
    return new ArrayList<>(supervivientes);
    }
    
    public List <Superviviente> filtrarPorNivel (NivelExperiencia nivel){
    if (nivel == null){
        throw new IllegalArgumentException("el nivel no puede ser nulo");
    }
    List<Superviviente> resultado = new ArrayList<>();
    for(Superviviente s: supervivientes){
        if (s.getNivelDeExperiencia() == nivel){
            resultado.add(s);
        }
    }
    return resultado;
    }
    
    public List<Superviviente> obtenerDisponiblesConAptitudMinima(int minimo){
        if (minimo < 0 ){
            throw new IllegalArgumentException("el minimo no puede ser negativo");
        }
        List<Superviviente> resultado = new ArrayList<>();
        for(Superviviente s: supervivientes){
        if (s.isEstadoDeDisponibilidad() &&(s.calcularAptitud()>= minimo)){
            resultado.add(s);
        }
    }
        return resultado;
    }
}
