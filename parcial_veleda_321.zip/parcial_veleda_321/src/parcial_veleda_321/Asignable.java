
package parcial_veleda_321;


public interface Asignable {
    void recibirTarea(String tarea);
}
