
package parcial_veleda_321;

public interface Capacitable {
    void capacitarse();
}
