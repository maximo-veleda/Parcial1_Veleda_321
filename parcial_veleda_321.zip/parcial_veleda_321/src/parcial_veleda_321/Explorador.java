package parcial_veleda_321;

public class Explorador extends Superviviente implements Asignable{
    private final int resistencia;
    
    
    public Explorador (String codigo, String nombre, NivelExperiencia nivel, boolean disponible, int resistencia){
        super(codigo, nombre, nivel, disponible);
        if(resistencia <= 0){
            throw new IllegalArgumentException("la resistencia debe ser positiva");
        }
        this.resistencia= resistencia;
    }
    
    public int getResistencia (){
    return resistencia ;
            }
    
    @Override
    public int calcularAptitud(){
    return resistencia * 2 ;
    }
    
   @Override
   public void recibirTarea(String tarea){
       setEstadoDeDisponibilidad(false);
   }

    @Override
    public String toString() {
        return super.toString() + " Explorador{" + "resistencia=" + resistencia + '}';
    }
   
   
   
   
}
