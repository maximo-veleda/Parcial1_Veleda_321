
package parcial_veleda_321;


public enum NivelExperiencia {
   NOVATO,
   INTERMEDIO ,
   EXPERTO,
}
