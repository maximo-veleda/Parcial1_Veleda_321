
package parcial_veleda_321;

public class SupervivienteDuplicadoException extends Exception{
    public SupervivienteDuplicadoException(String mensaje){
        super(mensaje);
    }
}
