
package parcial_veleda_321;

import java.util.List;

public class Main {

   
    public static void main(String[] args) {
        Refugio refugio = new Refugio("Horizonte");
        
        try{
        refugio.agregarSuperviviente(new Explorador(
       "EXP-101", "Ada", NivelExperiencia.EXPERTO, true, 30));
        refugio.agregarSuperviviente(new Medico(
        45, "MED-220", "Bruno", NivelExperiencia.INTERMEDIO, true));
        refugio.agregarSuperviviente(new Constructor(
        25, "CON-330", "Carla", NivelExperiencia.EXPERTO, true));
        refugio.agregarSuperviviente(new Explorador(
        "EXP-404", "Diego", NivelExperiencia.NOVATO, true, 18));
        refugio.agregarSuperviviente(new Medico(
        12, "EXP-101", "Ada", NivelExperiencia.NOVATO, true));
        } catch (SupervivienteDuplicadoException e){
            System.out.println ("no se pudo registrar:" + e.getMessage());
        }
        System.out.println("Supervivientes registrados:");
        mostrarSupervivientes(refugio.obtenerSupervivente());
        System.out.println("\nAptitudes:");
        mostrarAptitudes(refugio.obtenerSupervivente());
        System.out.println("\nAsignacion de tareas:");
        asignarTareas(refugio.obtenerSupervivente());
        System.out.println("\nCapacitaciones:");
        capacitarSupervivientes(refugio.obtenerSupervivente());
        System.out.println("\nDisponibles con aptitud >= 50:");
        mostrarSupervivientes(refugio.obtenerDisponiblesConAptitudMinima(50));
        System.out.println("\nSupervivientes EXPERTO:");
        mostrarSupervivientes(refugio.filtrarPorNivel(NivelExperiencia.EXPERTO));
        }
        private static void mostrarSupervivientes(List<Superviviente> lista) {
            for (Superviviente s : lista){
            System.out.println (s);
            }
        }
        private static void mostrarAptitudes(List<Superviviente> lista) {
           for (Superviviente s : lista){
               System.out.println(s.getNombre() + ":" + s.calcularAptitud());
           }
        }
        private static void asignarTareas(List<Superviviente> lista) {
         String tarea = "Mision de apoyo";
            for (Superviviente s : lista){
                if (s instanceof Asignable){
                ((Asignable)s).recibirTarea(tarea);
                System.out.println(s.getNombre()+ "no puede recibir tareas");
            }
        }

        }
        private static void capacitarSupervivientes(List<Superviviente> lista) {
            for (Superviviente s : lista){
                if (s instanceof Capacitable){
                    ((Capacitable)s).capacitarse();
                    System.out.println("se capacito a " + s.getNombre() + "(" + s.getCodigo() + ")." );
                }  else{
                    System.out.println(s.getNombre() + "no puede capacitarse");
                }
            }

        }
    }
    
